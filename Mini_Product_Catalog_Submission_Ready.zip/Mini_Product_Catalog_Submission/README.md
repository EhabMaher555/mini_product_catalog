# Mini Product Catalog — Homework Section 4

## Included
- `lib/main.dart`: Active go_router implementation, lifecycle logs, short-answer comments, and the requested commented Navigator reference implementation.
- `lib/product_widgets.dart`: Reusable product list and grid widgets.

## Run it
1. Create a new Flutter project:
   ```bash
   flutter create mini_product_catalog
   ```
2. Replace the generated `lib` folder with the `lib` folder in this package.
3. From the project root, add go_router:
   ```bash
   flutter pub add go_router
   ```
4. Run on web:
   ```bash
   flutter run -d chrome
   ```
5. Open the debug console/terminal and move through Login → Products → Details. Resize the browser on Products and capture the console output for submission.

## Submission reminder
The zip contains the `lib` folder, not the generated platform folders. Run `flutter pub add go_router` in the new project so Flutter writes the correct dependency version to `pubspec.yaml`.
