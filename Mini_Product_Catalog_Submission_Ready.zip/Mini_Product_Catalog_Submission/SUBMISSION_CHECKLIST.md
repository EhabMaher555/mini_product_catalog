# Submission checklist — Mini Product Catalog

The active app is implemented with `go_router`. The requested Navigator example is retained as commented reference code in `lib/main.dart`.

## Before submission
1. Open this folder in VS Code.
2. Open a terminal at the project root (the folder containing `README.md`).
3. If this folder is not yet a complete Flutter project, create a new project with `flutter create mini_product_catalog`, then copy this `lib` folder into it.
4. Run `flutter pub add go_router`.
5. Run `flutter run -d chrome`.
6. Test Login → Products → Details → Add to Cart.
7. Resize the browser while on Products and check the debug console lifecycle logs.
8. Take a real screenshot of the debug console and add it to this repository as `screenshots/lifecycle_console.png`.

## Important
No fabricated console screenshot is included. The screenshot must come from a real run of the app on a Flutter environment.
