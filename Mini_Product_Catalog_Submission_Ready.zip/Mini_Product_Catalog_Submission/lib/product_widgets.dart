import 'package:flutter/material.dart';

/// Shared product widgets used by both the ListView and GridView layouts.
/// [onProductTap] receives the tapped product's index in [products].
typedef ProductTapCallback = Future<void> Function(int index);
typedef FavoriteCallback = void Function();

class ProductsListView extends StatelessWidget {
  final List<Map<String, dynamic>> products;
  final FavoriteCallback onFavoritePressed;
  final ProductTapCallback onProductTap;

  const ProductsListView({
    super.key,
    required this.products,
    required this.onFavoritePressed,
    required this.onProductTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.only(bottom: 12),
      itemCount: products.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, index) => _ProductCard(
        product: products[index],
        onFavoritePressed: onFavoritePressed,
        onTap: () => onProductTap(index),
        isGrid: false,
      ),
    );
  }
}

class ProductsGridView extends StatelessWidget {
  final List<Map<String, dynamic>> products;
  final FavoriteCallback onFavoritePressed;
  final ProductTapCallback onProductTap;

  const ProductsGridView({
    super.key,
    required this.products,
    required this.onFavoritePressed,
    required this.onProductTap,
  });

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final columns = width >= 1000 ? 3 : 2;
    return GridView.builder(
      padding: const EdgeInsets.only(bottom: 12),
      itemCount: products.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: columns,
        crossAxisSpacing: 14,
        mainAxisSpacing: 14,
        childAspectRatio: 1.35,
      ),
      itemBuilder: (context, index) => _ProductCard(
        product: products[index],
        onFavoritePressed: onFavoritePressed,
        onTap: () => onProductTap(index),
        isGrid: true,
      ),
    );
  }
}

class _ProductCard extends StatelessWidget {
  final Map<String, dynamic> product;
  final FavoriteCallback onFavoritePressed;
  final VoidCallback onTap;
  final bool isGrid;

  const _ProductCard({
    required this.product,
    required this.onFavoritePressed,
    required this.onTap,
    required this.isGrid,
  });

  @override
  Widget build(BuildContext context) {
    final name = product['name'] as String;
    final price = (product['price'] as num).toDouble();
    final icon = product['icon'] as IconData? ?? Icons.shopping_bag_outlined;
    final primary = Theme.of(context).colorScheme.primary;

    return Card(
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                width: isGrid ? 58 : 64,
                height: isGrid ? 58 : 64,
                decoration: BoxDecoration(
                  color: primary.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Icon(icon, size: 30, color: primary),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 7),
                    Text(
                      '\$${price.toStringAsFixed(2)}',
                      style: TextStyle(
                        color: primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    if (!isGrid) ...[
                      const SizedBox(height: 4),
                      const Text(
                        'Tap to view details',
                        style: TextStyle(color: Colors.black45, fontSize: 12),
                      ),
                    ],
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Add to favorites',
                onPressed: onFavoritePressed,
                icon: const Icon(Icons.favorite_border_rounded),
                color: Colors.red,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
