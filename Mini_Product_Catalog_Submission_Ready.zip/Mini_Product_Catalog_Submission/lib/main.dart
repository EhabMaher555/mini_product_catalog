/*
HOMEWORK – SECTION 4: STATE LIFECYCLE & NAVIGATION
Project: Mini Product Catalog

PART 1 – LIFECYCLE ANSWERS
a) On a page's first creation, initState() runs first, then didChangeDependencies(), then build().
b) Pressing a heart calls setState(), so build() runs again. initState() does not run again.
c) When a page is removed, deactivate() runs, followed by dispose() when the State is permanently removed.
   With go_router, navigation using go() may replace/remove the current page. push() keeps the previous
   page in the navigation stack, so it can remain alive while DetailsPage is shown.
d) When the browser width changes, MediaQuery updates. Because ProductsPage reads MediaQuery in
   didChangeDependencies(), didChangeDependencies() runs again, then build() runs to update the
   width text and switch between list (< 600) and grid (>= 600).

PART 4 – SHORT ANSWERS
1) context.go replaces the current route/location (example: Login -> Products using goNamed).
   context.push adds a page on top of the current route (example: Products -> Details using push).
2) go is used for Login -> Products because login should no longer be the active page to return to.
   push is used for Details because the user should return to Products after viewing a product.
3) A path parameter is part of the route path, e.g. /details/Headphones/80 (name and price).
   A query parameter comes after ?, e.g. /products?user=Guest.

The Navigator implementation requested in Part 2 is kept below as commented-out code.
The active app uses go_router as required for submission.
*/

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'product_widgets.dart';

void main() {
  runApp(const MiniProductCatalogApp());
}

final GoRouter _router = GoRouter(
  initialLocation: '/',
  routes: <RouteBase>[
    GoRoute(
      path: '/',
      name: 'login',
      builder: (BuildContext context, GoRouterState state) {
        return const LoginPage();
      },
    ),
    GoRoute(
      path: '/products',
      name: 'products',
      builder: (BuildContext context, GoRouterState state) {
        final username = state.uri.queryParameters['user'] ?? 'Guest';
        return ProductsPage(username: username);
      },
    ),
    GoRoute(
      path: '/details/:name/:price',
      name: 'details',
      builder: (BuildContext context, GoRouterState state) {
        final name = state.pathParameters['name'] ?? 'Product';
        final price = double.tryParse(state.pathParameters['price'] ?? '') ?? 0;
        return DetailsPage(name: name, price: price);
      },
    ),
  ],
);

class MiniProductCatalogApp extends StatelessWidget {
  const MiniProductCatalogApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'Mini Product Catalog',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF3157A4)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF6F7FB),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFF6F7FB),
          surfaceTintColor: Colors.transparent,
          centerTitle: false,
        ),
        cardTheme: CardThemeData(
          elevation: 1,
          color: Colors.white,
          surfaceTintColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
        ),
      ),
      routerConfig: _router,
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  void initState() {
    super.initState();
    print('LoginPage: initState');
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    print('LoginPage: didChangeDependencies');
  }

  @override
  Widget build(BuildContext context) {
    print('LoginPage: build');
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(30),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Container(
                        height: 76,
                        width: 76,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.primaryContainer,
                          borderRadius: BorderRadius.circular(24),
                        ),
                        child: Icon(
                          Icons.shopping_bag_outlined,
                          size: 42,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                      ),
                      const SizedBox(height: 24),
                      Text(
                        'Mini Product Catalog',
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Explore the collection and find something you love.',
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                              color: Colors.black54,
                            ),
                      ),
                      const SizedBox(height: 28),
                      const Text(
                        'Demo account',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 6),
                      const Text('You will continue as Guest. No form is required.'),
                      const SizedBox(height: 22),
                      FilledButton.icon(
                        onPressed: () {
                          // Part 3: go_router active implementation.
                          context.goNamed(
                            'products',
                            queryParameters: const {'user': 'Guest'},
                          );
                        },
                        icon: const Icon(Icons.arrow_forward_rounded),
                        label: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 13),
                          child: Text('Login as Guest'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void deactivate() {
    print('LoginPage: deactivate');
    super.deactivate();
  }

  @override
  void dispose() {
    print('LoginPage: dispose');
    super.dispose();
  }
}

class ProductsPage extends StatefulWidget {
  final String username;

  const ProductsPage({super.key, this.username = 'Guest'});

  @override
  State<ProductsPage> createState() => _ProductsPageState();
}

class _ProductsPageState extends State<ProductsPage> {
  double _screenWidth = 0;
  int _favorites = 0;
  String _cartMessage = '';

  final List<Map<String, dynamic>> _products = const [
    {'name': 'Wireless Headphones', 'price': 79.99, 'icon': Icons.headphones_rounded},
    {'name': 'Smart Watch', 'price': 129.50, 'icon': Icons.watch_rounded},
    {'name': 'Laptop Stand', 'price': 34.00, 'icon': Icons.laptop_mac_rounded},
    {'name': 'Travel Backpack', 'price': 59.95, 'icon': Icons.backpack_rounded},
    {'name': 'Bluetooth Speaker', 'price': 45.00, 'icon': Icons.speaker_rounded},
    {'name': 'Desk Lamp', 'price': 28.75, 'icon': Icons.light_rounded},
  ];

  @override
  void initState() {
    super.initState();
    print('ProductsPage: initState');
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final size = MediaQuery.sizeOf(context);
    _screenWidth = size.width;
    print(
      'ProductsPage: didChangeDependencies -> width: ${size.width}, height: ${size.height}',
    );
  }

  void _onFavoritePressed() {
    setState(() {
      _favorites++;
    });
  }

  Future<void> _openDetails(int index) async {
    final product = _products[index];
    final result = await context.pushNamed<String>(
      'details',
      pathParameters: {
        'name': product['name'] as String,
        'price': (product['price'] as num).toStringAsFixed(2),
      },
    );

    if (!mounted) return;
    if (result != null) {
      setState(() {
        _cartMessage = result;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    print('ProductsPage: build');
    final isWide = _screenWidth >= 600;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Discover Products',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.red.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.favorite, color: Colors.red, size: 18),
                    const SizedBox(width: 6),
                    Text('Favorites: $_favorites'),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Welcome, ${widget.username}',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 4),
              Text(
                'A few good things, picked for you.',
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Colors.black54,
                    ),
              ),
              const SizedBox(height: 8),
              Text(
                'Screen width: ${_screenWidth.toStringAsFixed(0)} px',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.black54,
                    ),
              ),
              if (_cartMessage.isNotEmpty) ...[
                const SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.green.withValues(alpha: 0.10),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    _cartMessage,
                    style: const TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
              const SizedBox(height: 14),
              Expanded(
                child: isWide
                    ? ProductsGridView(
                        products: _products,
                        onFavoritePressed: _onFavoritePressed,
                        onProductTap: _openDetails,
                      )
                    : ProductsListView(
                        products: _products,
                        onFavoritePressed: _onFavoritePressed,
                        onProductTap: _openDetails,
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void deactivate() {
    print('ProductsPage: deactivate');
    super.deactivate();
  }

  @override
  void dispose() {
    print('ProductsPage: dispose');
    super.dispose();
  }
}

class DetailsPage extends StatefulWidget {
  final String name;
  final double price;

  const DetailsPage({
    super.key,
    required this.name,
    required this.price,
  });

  @override
  State<DetailsPage> createState() => _DetailsPageState();
}

class _DetailsPageState extends State<DetailsPage> {
  @override
  void initState() {
    super.initState();
    print('DetailsPage: initState');
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    print('DetailsPage: didChangeDependencies');
  }

  @override
  Widget build(BuildContext context) {
    print('DetailsPage: build');
    return Scaffold(
      appBar: AppBar(title: const Text('Product Details')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(28),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      height: 180,
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primaryContainer,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Icon(
                        Icons.inventory_2_outlined,
                        size: 88,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Text(
                      widget.name,
                      style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '\$${widget.price.toStringAsFixed(2)}',
                      style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                            color: Theme.of(context).colorScheme.primary,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'A useful everyday item with a clean design and great value.',
                    ),
                    const SizedBox(height: 26),
                    FilledButton.icon(
                      onPressed: () {
                        context.pop('${widget.name} added to cart');
                      },
                      icon: const Icon(Icons.add_shopping_cart_rounded),
                      label: const Padding(
                        padding: EdgeInsets.symmetric(vertical: 13),
                        child: Text('Add to Cart'),
                      ),
                    ),
                    const SizedBox(height: 8),
                    OutlinedButton(
                      onPressed: () => context.pop(),
                      child: const Text('Back to products'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void deactivate() {
    print('DetailsPage: deactivate');
    super.deactivate();
  }

  @override
  void dispose() {
    print('DetailsPage: dispose');
    super.dispose();
  }
}

/*
==============================================================================
PART 2 – NAVIGATOR VERSION (COMMENTED OUT AS REQUESTED)
==============================================================================
To try this version, change MaterialApp.router to MaterialApp, use routes below,
and comment out the GoRouter setup and active pages above. This version is kept
for reference and is NOT active in the submitted app.

class NavigatorMiniProductCatalogApp extends StatelessWidget {
  const NavigatorMiniProductCatalogApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/',
      routes: {
        '/': (context) => const NavigatorLoginPage(),
        '/products': (context) {
          final username = ModalRoute.of(context)!.settings.arguments as String;
          return NavigatorProductsPage(username: username);
        },
      },
    );
  }
}

class NavigatorLoginPage extends StatefulWidget {
  const NavigatorLoginPage({super.key});

  @override
  State<NavigatorLoginPage> createState() => _NavigatorLoginPageState();
}

class _NavigatorLoginPageState extends State<NavigatorLoginPage> {
  @override
  void initState() { super.initState(); print('NavigatorLoginPage: initState'); }
  @override
  void didChangeDependencies() { super.didChangeDependencies(); print('NavigatorLoginPage: didChangeDependencies'); }
  @override
  Widget build(BuildContext context) {
    print('NavigatorLoginPage: build');
    return Scaffold(
      body: Center(
        child: ElevatedButton(
          child: const Text('Login'),
          onPressed: () => Navigator.pushNamed(
            context,
            '/products',
            arguments: 'Guest',
          ),
        ),
      ),
    );
  }
  @override
  void deactivate() { print('NavigatorLoginPage: deactivate'); super.deactivate(); }
  @override
  void dispose() { print('NavigatorLoginPage: dispose'); super.dispose(); }
}

class NavigatorProductsPage extends StatefulWidget {
  final String username;
  const NavigatorProductsPage({super.key, required this.username});
  @override
  State<NavigatorProductsPage> createState() => _NavigatorProductsPageState();
}

class _NavigatorProductsPageState extends State<NavigatorProductsPage> {
  int favorites = 0;
  String cartMessage = '';
  final products = const [
    {'name': 'Wireless Headphones', 'price': 79.99},
    {'name': 'Smart Watch', 'price': 129.50},
    {'name': 'Laptop Stand', 'price': 34.00},
    {'name': 'Travel Backpack', 'price': 59.95},
    {'name': 'Bluetooth Speaker', 'price': 45.00},
    {'name': 'Desk Lamp', 'price': 28.75},
  ];
  @override
  void initState() { super.initState(); print('NavigatorProductsPage: initState'); }
  @override
  void didChangeDependencies() { super.didChangeDependencies(); print('NavigatorProductsPage: didChangeDependencies'); }
  Future<void> openDetails(int index) async {
    final product = products[index];
    final result = await Navigator.push<String>(
      context,
      MaterialPageRoute(
        builder: (_) => NavigatorDetailsPage(
          name: product['name'] as String,
          price: product['price'] as double,
        ),
      ),
    );
    if (!mounted) return;
    if (result != null) setState(() => cartMessage = result);
  }
  @override
  Widget build(BuildContext context) {
    print('NavigatorProductsPage: build');
    return Scaffold(
      appBar: AppBar(title: Text('Welcome, ${widget.username}')),
      body: Column(children: [
        Text('Favorites: $favorites'),
        if (cartMessage.isNotEmpty) Text(cartMessage),
        Expanded(
          child: ProductsListView(
            products: products,
            onFavoritePressed: () => setState(() => favorites++),
            onProductTap: openDetails,
          ),
        ),
      ]),
    );
  }
  @override
  void deactivate() { print('NavigatorProductsPage: deactivate'); super.deactivate(); }
  @override
  void dispose() { print('NavigatorProductsPage: dispose'); super.dispose(); }
}

class NavigatorDetailsPage extends StatefulWidget {
  final String name;
  final double price;
  const NavigatorDetailsPage({super.key, required this.name, required this.price});
  @override
  State<NavigatorDetailsPage> createState() => _NavigatorDetailsPageState();
}
class _NavigatorDetailsPageState extends State<NavigatorDetailsPage> {
  @override
  void initState() { super.initState(); print('NavigatorDetailsPage: initState'); }
  @override
  void didChangeDependencies() { super.didChangeDependencies(); print('NavigatorDetailsPage: didChangeDependencies'); }
  @override
  Widget build(BuildContext context) {
    print('NavigatorDetailsPage: build');
    return Scaffold(
      appBar: AppBar(title: const Text('Details')),
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(widget.name),
          Text('\$${widget.price.toStringAsFixed(2)}'),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, '${widget.name} added to cart'),
            child: const Text('Add to Cart'),
          ),
        ]),
      ),
    );
  }
  @override
  void deactivate() { print('NavigatorDetailsPage: deactivate'); super.deactivate(); }
  @override
  void dispose() { print('NavigatorDetailsPage: dispose'); super.dispose(); }
}
*/
